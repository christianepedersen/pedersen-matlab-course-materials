function [subtracted] = question1_subtract405(raw470,raw405)


subtracted = raw470 - raw405;


end

 